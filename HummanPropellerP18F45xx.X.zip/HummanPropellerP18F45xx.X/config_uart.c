/*
 * File:   config_uart.c
 * Author: optimus
 *
 * Created on August 20, 2018, 5:49 PM
 */
#include "config_uart.h"



