void UARTInit(void);

void UARTPutChar(char Dato);

void UART_String(char * _string);