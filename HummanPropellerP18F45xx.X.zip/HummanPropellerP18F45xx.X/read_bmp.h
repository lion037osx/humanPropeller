void read_bmp(void);
void read_bmp_start(void);