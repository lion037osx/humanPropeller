#ifndef STAR2_H
#define  STAR2_H
#define sar2_SIZE     3850
extern BITMAP_FLASH sar2;
#endif